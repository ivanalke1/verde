
        package com.verdeindice.utils

        import android.view.View
        import android.view.animation.AlphaAnimation

        object AnimationHelper {
            fun fadeIn(view: View) {
                val animation = AlphaAnimation(0f, 1f)
                animation.duration = 500
                view.startAnimation(animation)
            }
        }
    