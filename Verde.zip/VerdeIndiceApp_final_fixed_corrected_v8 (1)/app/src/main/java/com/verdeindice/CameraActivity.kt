
package com.verdeindice

import android.app.Activity
import android.content.Intent
import android.graphics.Bitmap
import android.os.Bundle
import android.provider.MediaStore
import android.widget.Button
import android.widget.ImageView
import androidx.appcompat.app.AppCompatActivity

class CameraActivity : AppCompatActivity() {

    private lateinit var imageView: ImageView
    private lateinit var btnAnalyze: Button
    private var capturedImage: Bitmap? = null
    private var nitrogen: String? = null
    private var phosphorus: String? = null
    private var potassium: String? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_camera)

        imageView = findViewById(R.id.imageView)
        btnAnalyze = findViewById(R.id.btnAnalyze)

        nitrogen = intent.getStringExtra("Nitrogen")
        phosphorus = intent.getStringExtra("Phosphorus")
        potassium = intent.getStringExtra("Potassium")

        val cameraIntent = Intent(MediaStore.ACTION_IMAGE_CAPTURE)
        startActivityForResult(cameraIntent, 100)

        btnAnalyze.setOnClickListener {
            val analysisIntent = Intent(this, AnalysisActivity::class.java)
            analysisIntent.putExtra("Nitrogen", nitrogen)
            analysisIntent.putExtra("Phosphorus", phosphorus)
            analysisIntent.putExtra("Potassium", potassium)
            analysisIntent.putExtra("CapturedImage", capturedImage)
            startActivity(analysisIntent)
        }
    }

    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == 100 && resultCode == Activity.RESULT_OK) {
            capturedImage = data?.extras?.get("data") as Bitmap
            imageView.setImageBitmap(capturedImage)
        }
    }
}
