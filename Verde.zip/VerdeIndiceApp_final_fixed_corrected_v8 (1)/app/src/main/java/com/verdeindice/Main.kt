
// Package declaration
package com.example.myapp

// Top-level property
val myTopLevelVariable: Int = 10

// Top-level function
fun myTopLevelFunction() {
    println("This is a top-level function")
}

// Top-level class
class MyClass {
    // Class-level property
    val myClassVariable: String = "Hello"

    // Class-level function
    fun myClassFunction() {
        println("This is a class function, value: $myClassVariable")
    }
}

// Top-level object
object MyObject {
    fun myObjectFunction() {
        println("This is an object function")
    }
}

// Top-level interface
interface MyInterface {
    fun myInterfaceFunction()
}

// Top-level type alias
typealias MyString = String

// Top-level annotation
@Target(AnnotationTarget.CLASS)
annotation class MyAnnotation

// Main function
fun main() {
    // Call top-level function
    myTopLevelFunction()

    // Instantiate class and call method
    val myClassInstance = MyClass()
    myClassInstance.myClassFunction()

    // Use object function
    MyObject.myObjectFunction()
}
