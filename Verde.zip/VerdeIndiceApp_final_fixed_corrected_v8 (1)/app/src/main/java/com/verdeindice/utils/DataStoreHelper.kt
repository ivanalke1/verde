package com.verdeindice.utils

import android.content.Context
import androidx.datastore.preferences.core.Preferences
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.stringPreferencesKey
import androidx.datastore.preferences.preferencesDataStore
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map

// Estensione per il Context: inizializza DataStore correttamente
private val Context.dataStore by preferencesDataStore(name = "app_preferences")

object DataStoreHelper {

    suspend fun savePreference(context: Context, key: String, value: String) {
        val dataKey = stringPreferencesKey(key) // Usa una chiave di stringa
        context.dataStore.edit { preferences -> 
            preferences[dataKey] = value
        }
    }

    fun readPreference(context: Context, key: String): Flow<String?> {
        val dataKey = stringPreferencesKey(key) // Usa una chiave di stringa
        return context.dataStore.data.map { preferences ->
            preferences[dataKey]
        }
    }
}
