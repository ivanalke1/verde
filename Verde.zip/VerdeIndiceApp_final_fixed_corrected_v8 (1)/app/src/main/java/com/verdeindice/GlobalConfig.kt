package com.verdeindice

// Top-level property
val myTopLevelVariable = 10

// Top-level function
fun myTopLevelFunction() {
    println("This is a top-level function")
}

// Top-level class
class MyClass {
    // Class-level property
    val myClassVariable = "Hello"

    // Class-level function
    fun myClassFunction() {
        println("This is a class function")
    }
}

// Top-level object
object MyObject {
    fun myObjectFunction() {
        println("This is an object function")
    }
}

// Top-level interface
interface MyInterface {
    fun myInterfaceFunction()
}

// Top-level type alias
typealias MyString = String

// Top-level annotation
@Target(AnnotationTarget.CLASS)
annotation class MyAnnotation

// Main function

fun main() {
    myTopLevelFunction()
    val myObject = MyObject
    myObject.myObjectFunction()
}