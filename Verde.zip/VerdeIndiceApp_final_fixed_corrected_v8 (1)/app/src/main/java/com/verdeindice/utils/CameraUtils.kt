
        package com.verdeindice.utils

        import android.graphics.Bitmap
        import android.graphics.BitmapFactory

        object CameraUtils {
            fun decodeBitmapFromPath(path: String): Bitmap? {
                return BitmapFactory.decodeFile(path)
            }
        }
    