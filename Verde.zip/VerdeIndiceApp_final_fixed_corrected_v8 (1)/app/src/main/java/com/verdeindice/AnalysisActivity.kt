
package com.verdeindice

import android.graphics.Bitmap
import android.os.Build
import android.os.Bundle
import android.widget.Button
import android.widget.ImageView
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity

class AnalysisActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_analysis)  // Deve essere prima di findViewById

        findViewById<Button>(R.id.buttonAnalyze)?.setOnClickListener {
            analyzeImage()
        }

        val imageView = findViewById<ImageView>(R.id.imageViewAnalysis)
        val resultTextView = findViewById<TextView>(R.id.textViewResult)

        val capturedImage = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            intent.getParcelableExtra("CapturedImage", Bitmap::class.java)
        } else {
            intent.getParcelableExtra<Bitmap>("CapturedImage")
        }
        
        val nitrogen = intent.getStringExtra("Nitrogen")?.toDoubleOrNull() ?: 0.0
        val phosphorus = intent.getStringExtra("Phosphorus")?.toDoubleOrNull() ?: 0.0
        val potassium = intent.getStringExtra("Potassium")?.toDoubleOrNull() ?: 0.0

        imageView.setImageBitmap(capturedImage)

        val greenIndex = calculateGreenIndex(nitrogen, phosphorus, potassium)
        resultTextView.text = "Green Index: %.2f".format(greenIndex)
    }

    private fun calculateGreenIndex(n: Double, p: Double, k: Double): Double {
        return (n * 0.4) + (p * 0.3) + (k * 0.3)  // Formula di esempio
    }

    private fun analyzeImage() {
        println("Analisi dell'immagine in corso...")
        // Logica di analisi immagine
    }
}
