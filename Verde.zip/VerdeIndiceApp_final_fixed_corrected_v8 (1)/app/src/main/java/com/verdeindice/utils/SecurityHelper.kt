
        package com.verdeindice.utils

        import java.security.MessageDigest

        object SecurityHelper {
            fun hashString(input: String): String {
                val bytes = MessageDigest.getInstance("SHA-256").digest(input.toByteArray())
                return bytes.joinToString("") { "%02x".format(it) }
            }
        }
    